<?php

namespace App\Constant;

class GeneralConstants {

    public CONST STATUS_ACTIVE = true;
    public CONST STATUS_INACTIVE = false;
    public CONST URL_EXCHANGE = "https://api.exchangeratesapi.io/latest";
}