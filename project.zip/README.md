# aliciProject

clone project.
> https://github.com/Jose528187/aliciProject.git

make sure you have docker installed
## following next point
- go to the root of the project
- execute command : 
>  **./docker/setup.sh**

- open your explorer favorite: 
> **http//localhost:8181**

	
